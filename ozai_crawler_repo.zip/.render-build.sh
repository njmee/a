#!/usr/bin/env bash
npm install
npx playwright install chromium